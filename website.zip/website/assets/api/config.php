<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'Cs0wxRMVvoWrzbfMNZnZrCOt8');
    define('CONSUMER_SECRET', 'zVb8xjFpK6p6o8vLNWMpjXHl1KuKtD3sOcbRUsc3hLhBvSIQmd');

    // User Access Token
    define('ACCESS_TOKEN', '277859563-2NwY9C7XHzgs7CXUzivvjZPz9oaJENz5Ggw6MhOm');
    define('ACCESS_SECRET', 'MHAgvAjc9cBSkZyVj1CuxmSmZO4S63pOUCVw887gYkyO6');
	
	// Cache Settings
	define('CACHE_ENABLED', false);
	define('CACHE_LIFETIME', 3600); // in seconds
	define('HASH_SALT', md5(dirname(__FILE__)));